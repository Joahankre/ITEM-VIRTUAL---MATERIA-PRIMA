﻿Imports Inventor
Imports System.Windows.Forms

Public Class EditorController

    Private ReadOnly _app As Inventor.Application

    ' Construtor recebe instância do Inventor
    Public Sub New(app As Inventor.Application)
        _app = app
    End Sub

    ' ============================================================
    ' EXECUTA O CONTROLLER
    ' ============================================================
    Public Sub Executar()

        ' Verifica se há uma montagem aberta
        If _app.ActiveDocumentType <> DocumentTypeEnum.kAssemblyDocumentObject Then
            MessageBox.Show("Abra uma montagem (.iam) antes de usar esta função.", "Aviso")
            Exit Sub
        End If

        Dim asmDoc As AssemblyDocument = _app.ActiveDocument

        ' Cria o form passando a instância do Inventor
        Dim frmSel As New FormSelecao(_app)

        ' Habilita a BOM estruturada
        Dim bom = asmDoc.ComponentDefinition.BOM
        bom.StructuredViewEnabled = True

        ' Monta árvore do BOM no TreeListView
        frmSel.MontarArvoreEstruturada(bom)

        ' Mostra o form para o usuário
        If frmSel.ShowDialog() <> DialogResult.OK Then Exit Sub

        ' Obtém documentos selecionados no form
        Dim docs = frmSel.RetornarDocumentos(_app)

        If docs.Count = 0 Then
            MessageBox.Show("Nenhum item selecionado.", "Aviso")
            Exit Sub
        End If

        ' Aqui você pode aplicar propriedades ou outras ações nos documentos
        ' Exemplo: apenas mostrando mensagem
        MessageBox.Show("Propriedades aplicadas com sucesso!", "Sucesso")
    End Sub

End Class