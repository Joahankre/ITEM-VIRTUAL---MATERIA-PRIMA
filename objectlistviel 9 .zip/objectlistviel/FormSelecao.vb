﻿Imports System.Text
Imports System.Windows.Forms
Imports BrightIdeasSoftware
Imports Inventor
Imports System.IO
Imports System.Collections.Specialized
Imports System.Drawing

Public Class FormSelecao

    Private AppInventor As Inventor.Application

    ' Construtor padrão (pode ser usado se não houver Inventor)
    Public Sub New()
        InitializeComponent()
        ConfigurarOLV()
    End Sub

    ' Construtor com instância do Inventor
    Public Sub New(app As Inventor.Application)
        InitializeComponent()
        AppInventor = app
        ConfigurarOLV()
    End Sub

    ' ============================================================
    ' CLASSE INTERNA – REPRESENTAÇÃO DOS ITENS DO BOM
    ' ============================================================
    Public Class BomItem
        Public Property ItemNumber As String
        Public Property Quantity As Double
        Public Property FilePath As String
        Public Property Children As New List(Of BomItem)
        Public Property Campos As New Dictionary(Of String, String)
        Public Property EhPurchased As Boolean = False

        ' ===== NOVAS PROPRIEDADES PARA ITENS VIRTUAIS =====
        Public Property EhVirtual As Boolean = False
        Public Property TipoVirtual As String = "" ' Ex.: "MP"
    End Class

    ' ============================================================
    ' CONFIGURAÇÃO DAS COLUNAS
    ' ============================================================
    Private Sub CriarColuna(nomeColuna As String, Optional ehPrimeira As Boolean = False)
        Dim col As New OLVColumn()
        col.Text = nomeColuna
        col.Width = 120

        col.AspectGetter = Function(x)
                               Dim item = CType(x, BomItem)
                               Select Case nomeColuna
                                   Case "Item" : Return item.ItemNumber
                                   Case "Quantidade" : Return item.Quantity
                                   Case "Caminho" : Return item.FilePath
                                   Case Else
                                       If item.Campos.ContainsKey(nomeColuna) Then
                                           Return item.Campos(nomeColuna)
                                       End If
                               End Select
                               Return ""
                           End Function

        If ehPrimeira Then
            col.ImageGetter = Function(x) RetornarIcone(x)
        End If

        tlvModelos.Columns.Add(col)

    End Sub

    Private Sub ConfigurarOLV()
        tlvModelos.Columns.Clear()
        tlvModelos.CanExpandGetter = Function(x) CType(x, BomItem).Children.Count > 0
        tlvModelos.ChildrenGetter = Function(x) CType(x, BomItem).Children
        tlvModelos.CheckBoxes = True
        tlvModelos.SmallImageList = imgIcons

        tlvModelos.AllowColumnReorder = True
        tlvModelos.UseFiltering = True
        tlvModelos.ShowFilterMenuOnRightClick = True
        tlvModelos.HeaderWordWrap = True

        ' Colunas padrão
        CriarColuna("Item", True)
        CriarColuna("Part Number")
        CriarColuna("Quantidade")
        CriarColuna("Mass")
        CriarColuna("Thickness")
        CriarColuna("Category")
        CriarColuna("Material")
        CriarColuna("Caminho")

        ' ===== APLICAR FORMATAÇÃO DE LINHA PARA ITENS VIRTUAIS =====
        tlvModelos.RowFormatter = Sub(row As OLVListItem)
                                      Dim item As BomItem = CType(row.RowObject, BomItem)

                                      If item.EhVirtual Then
                                          row.ForeColor = System.Drawing.Color.Red           ' Cor do texto
                                          row.BackColor = System.Drawing.Color.LightYellow   ' Fundo opcional
                                      Else
                                          row.ForeColor = System.Drawing.Color.Black         ' Cor normal
                                          row.BackColor = System.Drawing.Color.White         ' Fundo normal
                                      End If
                                  End Sub
    End Sub



    Private Function RetornarIcone(rowObject As Object) As Object
        Dim item As BomItem = CType(rowObject, BomItem)
        If item.Children IsNot Nothing AndAlso item.Children.Count > 0 Then Return "folder"
        Dim ext As String = IO.Path.GetExtension(item.FilePath).ToLower()
        Select Case ext
            Case ".ipt" : Return "ipt"
            Case ".iam" : Return "iam"
            Case ".idw", ".dwg" : Return "idw"
            Case Else : Return "unknown"
        End Select
    End Function

    ' ============================================================
    ' MONTAR ÁRVORE DO BOM
    ' ============================================================
    Public Sub MontarArvoreEstruturada(bom As Inventor.BOM)
        bom.StructuredViewEnabled = True
        bom.StructuredViewFirstLevelOnly = False

        Dim structView As BOMView = Nothing
        For Each v As BOMView In bom.BOMViews
            If v.ViewType = BOMViewTypeEnum.kStructuredBOMViewType Then
                structView = v : Exit For
            End If
        Next

        If structView Is Nothing Then
            MessageBox.Show("Structured BOM não foi criada pelo Inventor.", "Erro")
            Exit Sub
        End If

        If structView.BOMRows.Count = 0 Then
            MessageBox.Show("Structured BOM existe mas está vazia.", "Erro")
            Exit Sub
        End If

        Dim lista As New List(Of BomItem)
        For Each row As BOMRow In structView.BOMRows
            lista.Add(CriarBomNodeEstruturado(row))
        Next

        tlvModelos.Roots = lista
        tlvModelos.ExpandAll()
        ' --------- ORDENAR ANTES DE ATRIBUIR AO TreeListView ----------
        lista = lista.OrderBy(Function(x) x, Comparer(Of BomItem).Create(AddressOf CompararItemBOM)).ToList()

        ' Se quiser, também ordena os filhos recursivamente
        For Each root In lista
            OrdenarFilhos(root)
        Next
        ' ----------------------------------------------------------------

        tlvModelos.Roots = lista
        tlvModelos.ExpandAll()
    End Sub

    Private Sub OrdenarFilhos(item As BomItem)
        ' Ordena os filhos deste item
        item.Children = item.Children.OrderBy(Function(c) c, Comparer(Of BomItem).Create(AddressOf CompararItemBOM)).ToList()

        ' Chama recursivamente para os filhos
        For Each child In item.Children
            OrdenarFilhos(child)
        Next
    End Sub

    Private Function CriarBomNodeEstruturado(row As BOMRow) As BomItem

        Dim item As New BomItem With {
        .ItemNumber = row.ItemNumber
    }

        ' Quantidade
        Try
            item.Quantity = row.ItemQuantity
        Catch
            item.Quantity = 1
        End Try

        ' BOM Structure
        item.Campos("BOM Structure") = ObterTextoBOMStructure(row.BOMStructure)

        ' Marca itens Purchased
        If row.BOMStructure = BOMStructureEnum.kPurchasedBOMStructure Then
            item.EhPurchased = True
        End If

        ' Documento (se houver)
        If row.ComponentDefinitions.Count > 0 Then
            Dim doc As Document = row.ComponentDefinitions.Item(1).Document
            item.FilePath = doc.FullFileName

            ' Propriedades do documento
            For Each propSet As PropertySet In doc.PropertySets
                For Each prop As Inventor.Property In propSet
                    If prop.Value IsNot Nothing AndAlso Not item.Campos.ContainsKey(prop.Name) Then
                        item.Campos(prop.Name) = prop.Value.ToString()
                    End If
                Next
            Next

            ' Detecta Sheet Metal e cria nó virtual MP
            If EhSheetMetal(doc) Then
                Dim massaValor As Double = 0
                Try
                    Dim massaProp = doc.PropertySets.Item("Design Tracking Properties").Item("Mass")
                    Double.TryParse(massaProp.Value.ToString(), massaValor)
                Catch
                    massaValor = 0
                End Try

                ' Converte massa de gramas para kg
                Dim massaKg As Double = massaValor / 1000.0

                Dim mpItem As New BomItem With {
    .ItemNumber = item.ItemNumber & ".1",
    .Quantity = Math.Round(massaKg, 4),
    .FilePath = item.FilePath,
    .EhVirtual = True,
    .TipoVirtual = "MP"
}

                If item.Campos.ContainsKey("Part Number") Then
                    mpItem.Campos("Part Number") = item.Campos("Part Number")
                End If

                mpItem.Campos("Description") = "MATERIA PRIMA"
                mpItem.Campos("Material") = If(item.Campos.ContainsKey("Material"), item.Campos("Material"), "")
                mpItem.Campos("Tipo") = "MP"
                mpItem.Campos("BOM Structure") = "Virtual"

                item.Children.Add(mpItem)
            End If
        End If

        ' Adiciona filhos **somente se não for Purchased**
        If Not item.EhPurchased AndAlso row.ChildRows IsNot Nothing Then
            For Each child As BOMRow In row.ChildRows
                item.Children.Add(CriarBomNodeEstruturado(child))
            Next
        End If

        Return item
    End Function

    Private Function ObterTextoBOMStructure(estrutura As BOMStructureEnum) As String
        Select Case estrutura
            Case BOMStructureEnum.kNormalBOMStructure
                Return "Normal"
            Case BOMStructureEnum.kPurchasedBOMStructure
                Return "Purchased"
            Case BOMStructureEnum.kPhantomBOMStructure
                Return "Phantom"
            Case BOMStructureEnum.kReferenceBOMStructure
                Return "Reference"
            Case BOMStructureEnum.kInseparableBOMStructure
                Return "Inseparable"
            Case Else
                Return estrutura.ToString()
        End Select
    End Function

    Private Function ObterTodasPropriedades(doc As Document) As List(Of String)
        Dim lista As New List(Of String)
        For Each propSet As PropertySet In doc.PropertySets
            For Each prop As Inventor.Property In propSet
                If Not lista.Contains(prop.Name) Then lista.Add(prop.Name)
            Next
        Next
        Return lista
    End Function

    Private Function EhSheetMetal(doc As Document) As Boolean
        Return doc.SubType = "{9C464203-9BAE-11D3-8BAD-0060B0CE6BB4}"
    End Function

    ' ============================================================
    ' SALVAR/RESTAURAR LAYOUT DE COLUNAS
    ' ============================================================
    Private Sub SalvarLayout()
        If My.Settings.ColunasSalvas Is Nothing Then
            My.Settings.ColunasSalvas = New StringCollection()
        End If

        My.Settings.ColunasSalvas.Clear()

        For Each col As OLVColumn In tlvModelos.Columns.Cast(Of OLVColumn)().OrderBy(Function(c) c.DisplayIndex)
            My.Settings.ColunasSalvas.Add(col.Text)
        Next

        For i As Integer = 0 To tlvModelos.Columns.Count - 1
            tlvModelos.Columns(i).DisplayIndex = i
        Next

        My.Settings.Save()
    End Sub

    Private Sub RestaurarLayout()

        If My.Settings.ColunasSalvas Is Nothing OrElse My.Settings.ColunasSalvas.Count = 0 Then Exit Sub

        tlvModelos.BeginUpdate()
        tlvModelos.Columns.Clear()

        For Each item In My.Settings.ColunasSalvas

            Dim partes = item.Split("|"c)
            Dim nome = partes(0)
            Dim largura = Integer.Parse(partes(1))

            CriarColuna(nome)

            tlvModelos.Columns(tlvModelos.Columns.Count - 1).Width = largura

        Next

        tlvModelos.EndUpdate()

    End Sub

    Private Sub AplicarColunas(listaColunas As List(Of String))

        ' LIMPA TUDO PRIMEIRO
        tlvModelos.BeginUpdate()
        tlvModelos.ClearObjects()
        tlvModelos.Columns.Clear()

        ' Cria colunas fixas
        CriarColuna("Item", True)
        CriarColuna("Quantidade")

        ' Evita duplicações
        For Each nome In listaColunas.Distinct()
            If nome <> "Item" AndAlso nome <> "Quantidade" Then
                CriarColuna(nome)
            End If
        Next

        tlvModelos.EndUpdate()

    End Sub

    ' ============================================================
    ' EXPORTAR PARA CSV
    ' ============================================================
    Public Sub ExportarParaCSV(caminhoArquivo As String)
        Dim sb As New StringBuilder()
        Dim nomesColunas = tlvModelos.Columns.Cast(Of OLVColumn)().Select(Function(c) c.Text)
        sb.AppendLine(String.Join(";", nomesColunas))
        For Each root As BomItem In tlvModelos.Roots
            AdicionarLinhaCSV(root, sb)
        Next
        System.IO.File.WriteAllText(caminhoArquivo, sb.ToString(), Encoding.UTF8)
    End Sub

    Private Sub AdicionarLinhaCSV(item As BomItem, sb As StringBuilder)
        Dim valores As New List(Of String)
        For Each col As OLVColumn In tlvModelos.Columns
            Dim valor = col.AspectGetter(item)
            valores.Add("""" & valor.ToString().Replace("""", """""") & """")
        Next
        sb.AppendLine(String.Join(";", valores))

        ' Adiciona filhos apenas se não for Purchased
        If Not item.EhPurchased Then
            Dim filhosOrdenados = item.Children.OrderBy(Function(c) c, Comparer(Of BomItem).Create(AddressOf CompararItemBOM))
            For Each child In filhosOrdenados
                AdicionarLinhaCSV(child, sb)
            Next
        End If
    End Sub

    ' ============================================================
    ' RETORNAR DOCUMENTOS SELECIONADOS
    ' ============================================================
    Public Function RetornarDocumentos(app As Inventor.Application) As List(Of Document)
        Dim lista As New List(Of Document)
        For Each o As Object In tlvModelos.CheckedObjects
            Dim item As BomItem = CType(o, BomItem)
            If IO.File.Exists(item.FilePath) Then
                Try
                    lista.Add(app.Documents.Open(item.FilePath, False))
                Catch
                End Try
            End If
        Next
        Return lista
    End Function

    Private Function CompararItemBOM(x As Object, y As Object) As Integer
        Dim a As BomItem = CType(x, BomItem)
        Dim b As BomItem = CType(y, BomItem)

        Dim aParts = a.ItemNumber.Split("."c).Select(Function(s) Integer.Parse(s)).ToArray()
        Dim bParts = b.ItemNumber.Split("."c).Select(Function(s) Integer.Parse(s)).ToArray()

        Dim maxLen = Math.Max(aParts.Length, bParts.Length)

        For i As Integer = 0 To maxLen - 1
            Dim valA = If(i < aParts.Length, aParts(i), 0)
            Dim valB = If(i < bParts.Length, bParts(i), 0)

            If valA <> valB Then Return valA.CompareTo(valB)
        Next

        Return 0
    End Function

    ' ============================================================
    ' BOTÕES
    ' ============================================================
    Private Sub btnSelTodos_Click(sender As Object, e As EventArgs) Handles btnSelTodos.Click
        tlvModelos.CheckAll()
    End Sub

    Private Sub btnDesSelTodos_Click(sender As Object, e As EventArgs) Handles btnDesSelTodos.Click
        tlvModelos.UncheckAll()
    End Sub

    Private Sub btnOK_Click(sender As Object, e As EventArgs) Handles btnOK.Click
        If Not tlvModelos.CheckedObjects.Cast(Of Object)().Any() Then
            MessageBox.Show("Selecione ao menos um modelo.", "Aviso")
            Exit Sub
        End If
        Me.DialogResult = DialogResult.OK
        Me.Close()
    End Sub

    Private Sub btnExportarCSV_Click(sender As Object, e As EventArgs) Handles btnExportarCSV.Click
        Using sfd As New SaveFileDialog()
            sfd.Filter = "CSV files (*.csv)|*.csv"
            sfd.FileName = "BOM.csv"
            If sfd.ShowDialog() = DialogResult.OK Then
                ExportarParaCSV(sfd.FileName)
            End If
        End Using
    End Sub

    Private Sub btnExpandir_Click(sender As Object, e As EventArgs) Handles btnExpandir.Click
        If tlvModelos.GetItemCount() = 0 Then Exit Sub

        tlvModelos.BeginUpdate()
        tlvModelos.ExpandAll()
        tlvModelos.EndUpdate()
    End Sub

    Private Sub btnRecolher_Click(sender As Object, e As EventArgs) Handles btnRecolher.Click
        If tlvModelos.GetItemCount() = 0 Then Exit Sub

        tlvModelos.BeginUpdate()
        tlvModelos.CollapseAll()
        tlvModelos.EndUpdate()
    End Sub

    Private Sub btnGerenciarColunas_Click(sender As Object, e As EventArgs) Handles btnGerenciarColunas.Click
        ' Verifica se BOM foi carregada
        If tlvModelos.Roots Is Nothing OrElse Not tlvModelos.Roots.Cast(Of Object)().Any() Then
            MessageBox.Show("Carregue a BOM primeiro.", "Aviso")
            Exit Sub
        End If

        ' Primeiro item
        Dim primeiroItem As BomItem = CType(tlvModelos.Roots.Cast(Of Object)().First(), BomItem)
        If String.IsNullOrEmpty(primeiroItem.FilePath) OrElse Not IO.File.Exists(primeiroItem.FilePath) Then
            MessageBox.Show("Arquivo do item não existe.", "Aviso")
            Exit Sub
        End If

        ' Verifica Inventor
        If AppInventor Is Nothing Then
            MessageBox.Show("Instância do Inventor não disponível.", "Erro")
            Exit Sub
        End If

        ' Abre documento
        Dim doc As Document = Nothing
        Try
            doc = AppInventor.Documents.Open(primeiroItem.FilePath, False)
        Catch ex As Exception
            MessageBox.Show("Erro ao abrir o documento: " & ex.Message, "Erro")
            Exit Sub
        End Try

        ' Obtem todas as propriedades
        Dim todasPropriedades As New List(Of String)

        ' iProperties do documento
        todasPropriedades.AddRange(ObterTodasPropriedades(doc))

        ' ===== COLUNAS TÉCNICAS DO BOM =====
        Dim colunasTecnicas As New List(Of String) From {
    "BOM Structure"
}

        For Each col In colunasTecnicas
            If Not todasPropriedades.Contains(col) Then
                todasPropriedades.Add(col)
            End If
        Next
        Dim colunasAtuais As List(Of String) = tlvModelos.Columns.Cast(Of OLVColumn)().Select(Function(c) c.Text).ToList()

        ' Chama formulário de gerenciamento de colunas
        Dim frm As New FormGerenciarColunas()
        frm.CarregarColunas(todasPropriedades, colunasAtuais)

        If frm.ShowDialog() = DialogResult.OK Then

            ' Guarda os dados atuais
            Dim roots = tlvModelos.Roots

            tlvModelos.BeginUpdate()

            ' Limpa completamente
            tlvModelos.ClearObjects()
            tlvModelos.Columns.Clear()

            ' Recria colunas
            CriarColuna("Item", True)
            CriarColuna("Quantidade")

            For Each nome In frm.ColunasSelecionadas.Distinct()
                If nome <> "Item" AndAlso nome <> "Quantidade" Then
                    CriarColuna(nome)
                End If
            Next

            ' Reatribui os dados
            tlvModelos.Roots = roots

            tlvModelos.EndUpdate()

        End If
    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs)
        ' Exemplo de evento se necessário
    End Sub
End Class