﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FormSelecao
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.btnSelTodos = New System.Windows.Forms.Button()
        Me.btnDesSelTodos = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btnExpandir = New System.Windows.Forms.Button()
        Me.btnGerenciarColunas = New System.Windows.Forms.Button()
        Me.btnExportarCSV = New System.Windows.Forms.Button()
        Me.btnOK = New System.Windows.Forms.Button()
        Me.tlvModelos = New BrightIdeasSoftware.TreeListView()
        Me.imgIcons = New System.Windows.Forms.ImageList(Me.components)
        Me.btnRecolher = New System.Windows.Forms.Button()
        Me.Panel1.SuspendLayout()
        CType(Me.tlvModelos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnSelTodos
        '
        Me.btnSelTodos.Location = New System.Drawing.Point(-1, 17)
        Me.btnSelTodos.Margin = New System.Windows.Forms.Padding(2)
        Me.btnSelTodos.Name = "btnSelTodos"
        Me.btnSelTodos.Size = New System.Drawing.Size(140, 32)
        Me.btnSelTodos.TabIndex = 1
        Me.btnSelTodos.Text = "Selecionar Todos "
        Me.btnSelTodos.UseVisualStyleBackColor = True
        '
        'btnDesSelTodos
        '
        Me.btnDesSelTodos.Location = New System.Drawing.Point(143, 17)
        Me.btnDesSelTodos.Margin = New System.Windows.Forms.Padding(2)
        Me.btnDesSelTodos.Name = "btnDesSelTodos"
        Me.btnDesSelTodos.Size = New System.Drawing.Size(158, 32)
        Me.btnDesSelTodos.TabIndex = 2
        Me.btnDesSelTodos.TabStop = False
        Me.btnDesSelTodos.Text = "Desmarcar Todos"
        Me.btnDesSelTodos.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.ControlDark
        Me.Panel1.Controls.Add(Me.btnRecolher)
        Me.Panel1.Controls.Add(Me.btnExpandir)
        Me.Panel1.Controls.Add(Me.btnGerenciarColunas)
        Me.Panel1.Controls.Add(Me.btnExportarCSV)
        Me.Panel1.Controls.Add(Me.btnOK)
        Me.Panel1.Controls.Add(Me.btnSelTodos)
        Me.Panel1.Controls.Add(Me.btnDesSelTodos)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel1.Location = New System.Drawing.Point(0, 561)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(2)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1286, 61)
        Me.Panel1.TabIndex = 4
        '
        'btnExpandir
        '
        Me.btnExpandir.Location = New System.Drawing.Point(305, 17)
        Me.btnExpandir.Margin = New System.Windows.Forms.Padding(2)
        Me.btnExpandir.Name = "btnExpandir"
        Me.btnExpandir.Size = New System.Drawing.Size(155, 32)
        Me.btnExpandir.TabIndex = 6
        Me.btnExpandir.TabStop = False
        Me.btnExpandir.Text = "Expandir"
        Me.btnExpandir.UseVisualStyleBackColor = True
        '
        'btnGerenciarColunas
        '
        Me.btnGerenciarColunas.Location = New System.Drawing.Point(945, 18)
        Me.btnGerenciarColunas.Margin = New System.Windows.Forms.Padding(2)
        Me.btnGerenciarColunas.Name = "btnGerenciarColunas"
        Me.btnGerenciarColunas.Size = New System.Drawing.Size(200, 32)
        Me.btnGerenciarColunas.TabIndex = 5
        Me.btnGerenciarColunas.TabStop = False
        Me.btnGerenciarColunas.Text = "GERENCIAR COLUNAS"
        Me.btnGerenciarColunas.UseVisualStyleBackColor = True
        '
        'btnExportarCSV
        '
        Me.btnExportarCSV.Location = New System.Drawing.Point(623, 18)
        Me.btnExportarCSV.Margin = New System.Windows.Forms.Padding(2)
        Me.btnExportarCSV.Name = "btnExportarCSV"
        Me.btnExportarCSV.Size = New System.Drawing.Size(114, 32)
        Me.btnExportarCSV.TabIndex = 4
        Me.btnExportarCSV.TabStop = False
        Me.btnExportarCSV.Text = "Exportar CSV"
        Me.btnExportarCSV.UseVisualStyleBackColor = True
        '
        'btnOK
        '
        Me.btnOK.Location = New System.Drawing.Point(741, 18)
        Me.btnOK.Margin = New System.Windows.Forms.Padding(2)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(200, 32)
        Me.btnOK.TabIndex = 3
        Me.btnOK.TabStop = False
        Me.btnOK.Text = "OK"
        Me.btnOK.UseVisualStyleBackColor = True
        '
        'tlvModelos
        '
        Me.tlvModelos.CellEditUseWholeCell = False
        Me.tlvModelos.CheckBoxes = True
        Me.tlvModelos.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tlvModelos.GridLines = True
        Me.tlvModelos.HideSelection = False
        Me.tlvModelos.Location = New System.Drawing.Point(0, 0)
        Me.tlvModelos.Name = "tlvModelos"
        Me.tlvModelos.ShowGroups = False
        Me.tlvModelos.ShowImagesOnSubItems = True
        Me.tlvModelos.Size = New System.Drawing.Size(1286, 561)
        Me.tlvModelos.TabIndex = 5
        Me.tlvModelos.UseCompatibleStateImageBehavior = False
        Me.tlvModelos.View = System.Windows.Forms.View.Details
        Me.tlvModelos.VirtualMode = True
        '
        'imgIcons
        '
        Me.imgIcons.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit
        Me.imgIcons.ImageSize = New System.Drawing.Size(16, 16)
        Me.imgIcons.TransparentColor = System.Drawing.Color.Transparent
        '
        'btnRecolher
        '
        Me.btnRecolher.Location = New System.Drawing.Point(464, 18)
        Me.btnRecolher.Margin = New System.Windows.Forms.Padding(2)
        Me.btnRecolher.Name = "btnRecolher"
        Me.btnRecolher.Size = New System.Drawing.Size(155, 32)
        Me.btnRecolher.TabIndex = 7
        Me.btnRecolher.TabStop = False
        Me.btnRecolher.Text = "Recolher"
        Me.btnRecolher.UseVisualStyleBackColor = True
        '
        'FormSelecao
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.DarkBlue
        Me.ClientSize = New System.Drawing.Size(1286, 622)
        Me.Controls.Add(Me.tlvModelos)
        Me.Controls.Add(Me.Panel1)
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.Name = "FormSelecao"
        Me.Opacity = 0.9R
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Formulário de Seleção - Developed by Kreimeier & Machado"
        Me.Panel1.ResumeLayout(False)
        CType(Me.tlvModelos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btnSelTodos As Windows.Forms.Button
    Friend WithEvents btnDesSelTodos As Windows.Forms.Button
    Friend WithEvents Panel1 As Windows.Forms.Panel
    Friend WithEvents btnOK As Windows.Forms.Button
    Friend WithEvents tlvModelos As BrightIdeasSoftware.TreeListView
    Friend WithEvents imgIcons As Windows.Forms.ImageList
    Friend WithEvents btnExportarCSV As Windows.Forms.Button
    Friend WithEvents btnGerenciarColunas As Windows.Forms.Button
    Friend WithEvents btnExpandir As Windows.Forms.Button
    Friend WithEvents btnRecolher As Windows.Forms.Button
End Class
