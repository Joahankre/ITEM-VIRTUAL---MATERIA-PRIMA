﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormGerenciarColunas
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnOK1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.clbColunas = New System.Windows.Forms.CheckedListBox()
        Me.SuspendLayout()
        '
        'btnOK1
        '
        Me.btnOK1.Location = New System.Drawing.Point(23, 431)
        Me.btnOK1.Name = "btnOK1"
        Me.btnOK1.Size = New System.Drawing.Size(257, 59)
        Me.btnOK1.TabIndex = 8
        Me.btnOK1.Text = "OK"
        Me.btnOK1.UseMnemonic = False
        Me.btnOK1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(325, 431)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(257, 59)
        Me.Button2.TabIndex = 9
        Me.Button2.Text = "Button2"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'clbColunas
        '
        Me.clbColunas.FormattingEnabled = True
        Me.clbColunas.Location = New System.Drawing.Point(12, 15)
        Me.clbColunas.Name = "clbColunas"
        Me.clbColunas.Size = New System.Drawing.Size(581, 379)
        Me.clbColunas.TabIndex = 10
        '
        'FormGerenciarColunas
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(626, 527)
        Me.Controls.Add(Me.clbColunas)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.btnOK1)
        Me.Name = "FormGerenciarColunas"
        Me.Text = "Gerenciar Colunas "
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btnOK1 As Windows.Forms.Button
    Friend WithEvents Button2 As Windows.Forms.Button

    Private Sub FormGerenciarColunas_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btnOK_Click(sender As Object, e As EventArgs) Handles btnOK1.Click

    End Sub

    Friend WithEvents clbColunas As Windows.Forms.CheckedListBox
End Class
