﻿Imports System.Windows.Forms

Public Class FormGerenciarColunas

    ' Propriedade que guarda as colunas selecionadas
    Public Property ColunasSelecionadas As New List(Of String)

    ' Carrega as colunas no CheckedListBox
    Public Sub CarregarColunas(listaCompleta As List(Of String), colunasAtuais As List(Of String))
        clbColunas.Items.Clear()

        For Each nome In listaCompleta
            Dim marcado = colunasAtuais.Contains(nome)
            clbColunas.Items.Add(nome, marcado)
        Next
    End Sub

    ' Evento do botão OK
    Private Sub btnOK1_Click(sender As Object, e As EventArgs) Handles btnOK1.Click
        ColunasSelecionadas.Clear()

        For Each item In clbColunas.CheckedItems
            ColunasSelecionadas.Add(item.ToString())
        Next

        Me.DialogResult = DialogResult.OK
        Me.Close()
    End Sub

End Class